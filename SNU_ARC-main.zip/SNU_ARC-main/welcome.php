
<?php
    ob_start();
    // include header.php file
    include ('header_loggedin.php');
?>
<!-- !start #header -->

<!-- start #main-site -->
<?php

include ('header_loggedin.php');
?>

<main id="main-site">
    <?php

    /*  include banner area  */
        include ('loggedin_index.php');
    /*  include banner area  */


        echo '<br>';


?>
