# SNU ARC
SNU ARC is a web portal which is specifically designed to cover basic needs of university students by providing them a Gate Pass Approval System, Pay Later Portal and also a portal which helps them to check the availability status of various gaming arena's and available club rooms in the University.
# User End

## Home Page
![Home Page](https://user-images.githubusercontent.com/65329637/169684770-d783a69e-4d1a-466d-9c4e-20e884c4f686.png)
## Gate Pass
![Gate Pass](https://user-images.githubusercontent.com/65329637/169684782-e8ff4c04-f3e9-4d05-9c50-4e2fe9b711fd.png)

## Footer
![footer](https://user-images.githubusercontent.com/65329637/169684786-c33f1293-83ea-49b3-b1b5-9b650a915818.png)

## Ground Selection
![Ground Selection](https://user-images.githubusercontent.com/65329637/169684789-23e46aec-3def-4a45-b909-4a13d7e48907.png)

## Profile Change
![Profile Change](https://user-images.githubusercontent.com/65329637/169684797-8676cc84-ac61-4bfd-bf32-a5ca5bc471b2.png)

## User Payments
![Due_Payment](https://user-images.githubusercontent.com/65329637/169685063-f2dbc20c-7fcd-4432-a809-45fdbf701560.png)

# Admin End
## Home Page
![Admin](https://user-images.githubusercontent.com/65329637/169684847-9908eb7d-8cfb-4082-8bc1-45f4afaf83d0.png)

## Venue Updation
![Add Venues](https://user-images.githubusercontent.com/65329637/169684849-af6dca92-9cd1-4ae6-a449-c49650607697.png)

# Vendor End
## HomePage
![Shop_Transactions](https://user-images.githubusercontent.com/65329637/169684877-945f159e-b0e8-45dc-9141-846f2bcba6e2.png)

## Wallet
![user_wallet](https://user-images.githubusercontent.com/65329637/169684882-2363f6f0-9bfc-4627-8cf7-5e68783a9259.png)

# Security End
## Approval Requests
![Security_Approval](https://user-images.githubusercontent.com/65329637/169684900-1a3e80a6-0d20-4630-b7a4-ebd04e2bcc7b.png)

## Approval Status
![Approvals](https://user-images.githubusercontent.com/65329637/169684937-26a30c0c-0f87-42c6-9161-fabbf75253d4.png)

# Steps to Launch
Download sunarc (1).sql and rename it to snuarc.sql, Import the database into phpmyadmin (preferably use XAMPP as local server) and add all the files to htdocs of xampp in C.
